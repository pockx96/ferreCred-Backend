/// Estructura de la tabla

CREATE TABLE `Deuda` ( 
    `folio` INT PRIMARY KEY NOT NULL,
    `fecha` VARCHAR(10),
    `cliente` VARCHAR(50),
    `total` DECIMAL(10, 2),
    `adeudo` DECIMAL(10, 2)
);


/// Query para consola

CREATE TABLE `deuda` ( `folio` VARCHAR(10) PRIMARY KEY NOT NULL,`fecha` VARCHAR(10),`cliente` VARCHAR(50),`total` DECIMAL(10, 2),`adeudo` DECIMAL(10, 2));

/// Funciones CRUD

SELECT * FROM Deuda; // Solo pruebas

SELECT * FROM Deuda WHERE folio = 1;
select * from deuda where cliente =?;
UPDATE Deuda SET adeudo = 250.00 WHERE folio = 1;
DELETE FROM Deuda WHERE folio = 1;


/// pruebas

