CREATE TABLE `catalogo_producto` (
  `codigo` INT PRIMARY KEY,
  `descripcion` VARCHAR(255),
  `precio_compra` DECIMAL(10, 2),
  `precio_venta` DECIMAL(10, 2),
  `tipo` VARCHAR(50)
);


//Consola
CREATE TABLE `catalogo_producto` (`codigo` INT PRIMARY KEY,`descripcion` VARCHAR(50),`precio_compra` DECIMAL(10, 2),`precio_venta` DECIMAL(10, 2),`tipo` VARCHAR(50));

//funciones CRUD
select * from catalogo_producto;
select * from catalogo_producto where codigo = ?;
SELECT * FROM catalogo_producto WHERE descripcion LIKE '%tornillos%';
INSERT into catalogo_producto VALUES(1,'martillo',15,16,'unitario');
DELETE * from catalogo_producto where codigo = ?;

