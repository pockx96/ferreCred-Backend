CREATE TABLE `usuarios` (
  `nombreUsuario` varchar(50) NOT NULL,
  `contraseñaUsuario` varchar(50) NOT NULL,
  `correoUsuario` varchar(50) NOT NULL
);

select * from usuarios where correo_electronico = '?';
DELETE from usuarios where correo_electronico = '?'
INSERT into usuarios VALUES('','','');