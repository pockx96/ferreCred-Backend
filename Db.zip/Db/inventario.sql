CREATE TABLE inventario (
  `codigo_producto` INT NOT NULL,
  `cantidad` INT NOT NULL
);

CREATE TABLE inventario (`codigo_producto` INT NOT NULL,`cantidad` INT NOT NULL);


select * from inventario where codigo_producto = ?;
INSERT INTO inventario VALUES(1,3);
UPDATE inventario set cantidad = 2 where codigo_producto = 1;